package com.example.demo;

public abstract class ResultStringClass {
    abstract  void showResultSting(String tempString);


}
